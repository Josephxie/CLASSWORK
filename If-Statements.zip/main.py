print ("Exercise 34")
print ("Please insert a number:")
integer = int(input())
even_or_odd = integer % 2
if even_or_odd > 0:
    print ("The number inserted is odd")
else:
    print ("The number inserted is even")

print ()
print ()
print ("Exercise 35")
print ("How old is your dogge?")
human_years = int(input())
if human_years >= 2:
    dog_years = human_years * 4 + 13
print (f"Your dog is {dog_years} years old.")

print ()
print ()
print ("Exercise 36")
print ("Please enter a letter in the alphabet")
letter = input()
if letter == ('a','e','i','o','u'):
    print ("That letter is a consonant")
else:
    print ("That letter is a vowel")
print ()
print ()

print ("Exercise 37")
print ("How many sides does your shape have?")
num_sides = int(input())
if num_sides == 3:
    print ("That's a triangle")
elif num_sides == 4: 
    print ("That's a quadrilateral")
elif num_sides == 5: 
    print ("That's a pentagon")
elif num_sides == 6:
    print ("That's a hexagon")
elif num_sides == 7:
    print ("That's a septagon")
elif num_sides == 8:
    print ("That's an octagon")
elif num_sides == 9:
    print ("That's a nonagon")
elif num_sides == 10:
    print ("That's a decagon")
else:
    print ("Error has occurred, that polygon/non polygon does not have the needed sides from 3-10")
print ()
print ()
print ("Exercise 48")
print ("What is the year you would like to know the animal for?")
year = int(input())
year_twelve = year % 12
if year_twelve == 1:
    print ("Dragon")
elif year_twelve == 2:
    print ("Snake")
elif year_twelve == 3:
    print ("Horse")
elif year_twelve == 4:
    print ("Sheep")
elif year_twelve == 5:
    print ("Monkey")
elif year_twelve == 6: 
    print ("Rooster")
elif year_twelve == 7:
    print ("Dog")
elif year_twelve == 8:
    print ("Pig")
elif year_twelve == 9:
    print ("Rat")
elif year_twelve == 10:
    print ("Ox")
elif year_twelve == 11:
    print ("Tiger")
elif year_twelve == 12: 
    print ("Hare")
print ()
print ()
